// import { createFileRoute } from '@tanstack/react-router'

// export const Route = createFileRoute('/_app/_auth/dashboard/apps/$appId/roles/$roleId/edit')({
//   component: () => <div>Hello /_app/_auth/dashboard/apps/$appId/roles/$roleId/edit!</div>
// })
import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { useQuery, useMutation } from "convex/react";
import { Id, Doc } from "@cvx/_generated/dataModel";
import { useEffect, useState } from "react";
import { Button } from "@/ui/button";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/roles/$roleId/edit"
)({
  component: EditRolePage,
});

function EditRolePage() {
  const { roleId } = Route.useParams();
  const { appId } = Route.useParams();
  const router = useRouter();

  const typedRoleId = roleId as Id<"roles">;

  const role = useQuery(api.roles.getRole, {
    roleId: typedRoleId,
  }) as Doc<"roles"> | null | undefined;

  const updateRole = useMutation(api.roles.updateRole);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [permissionsText, setPermissionsText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (role) {
      setName(role.name);
      setDescription(role.description ?? "");
      setPermissionsText(role.permissions.join(", "));
    }
  }, [role]);

  if (role === undefined) {
    return (
      <div className="px-4 py-4 text-sm text-primary/60">
        Loading role...
      </div>
    );
  }

  if (role === null) {
    return (
      <div className="px-4 py-4">
        <p className="text-sm text-destructive">Role not found.</p>
      </div>
    );
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const permissions = permissionsText
      .split(",")
      .map((p) => p.trim())
      .filter(Boolean);

    try {
      await updateRole({
        roleId: typedRoleId,
        name,
        description: description || undefined,
        permissions,
      });

      router.navigate({
        to: "/_app/_auth/dashboard/apps/$appId/roles/",
        params: { appId },
      });
    } catch (err: any) {
      setError(err.message ?? "Failed to update role");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-lg font-semibold">Edit Role</h1>

      <form
        onSubmit={onSubmit}
        className="space-y-4 max-w-lg rounded border border-border/60 bg-card px-4 py-4"
      >
        <div className="space-y-1">
          <label className="block text-sm">Name</label>
          <input
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm">Description</label>
          <textarea
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm">
            Permissions{" "}
            <span className="text-xs text-primary/60">
              (comma separated)
            </span>
          </label>
          <textarea
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm font-mono"
            rows={3}
            value={permissionsText}
            onChange={(e) => setPermissionsText(e.target.value)}
          />
        </div>

        {error && (
          <p className="text-sm text-destructive">{error}</p>
        )}

        <div className="flex items-center gap-3">
          <Button type="submit" disabled={loading}>
            {loading ? "Saving..." : "Save Changes"}
          </Button>
          <Link
            to="/_app/_auth/dashboard/apps/$appId/roles/"
            params={{ appId }}
            className="text-sm text-primary/70 hover:underline"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}
