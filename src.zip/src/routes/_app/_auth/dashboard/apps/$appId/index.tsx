import { createFileRoute } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { Id } from "@cvx/_generated/dataModel";
import { useQuery } from "convex/react";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/"
)({
  component: AppOverviewPage,
});

function AppOverviewPage() {
  const { appId } = Route.useParams();
  const typedId = appId as Id<"apps">;

  const app = useQuery(api.apps.getApp, { appId: typedId });

  if (!app) return <p>Loading...</p>;

  return (
    <div className="p-6 rounded border border-border">
      <p>Region: {app.region}</p>
      <p>Created: {app.createdAt}</p>
      <p>Status: Active</p>
    </div>
  );
}
