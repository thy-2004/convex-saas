// import { createFileRoute } from '@tanstack/react-router'

// export const Route = createFileRoute('/_app/_auth/dashboard/apps/$appId/users/')({
//   component: () => <div>Hello /_app/_auth/dashboard/apps/$appId/users/!</div>
// })
import { createFileRoute, Link } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { Id, Doc } from "@cvx/_generated/dataModel";
import { useQuery, useMutation } from "convex/react";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/users/"
)({
  component: AppUsersPage,
});

type AppUser = Doc<"appUsers">;
type Role = Doc<"roles">;

function AppUsersPage() {
  const { appId } = Route.useParams();
  const typedAppId = appId as Id<"apps">;

  const users = (useQuery(api.appUsers.listAppUsers, {
    appId: typedAppId,
  }) ?? []) as AppUser[];

  const roles = (useQuery(api.roles.listRoles, {
    appId: typedAppId,
  }) ?? []) as Role[];

  const deleteUser = useMutation(api.appUsers.deleteAppUser);

  const rolesMap = new Map<string, string>();
  roles.forEach((r) => rolesMap.set(r._id, r.name));

  const onDelete = async (userId: string) => {
    if (!confirm("Delete this user?")) return;
    await deleteUser({ userId });
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Users</h1>

        <Link
          to="/_app/_auth/dashboard/apps/$appId/users/new"
          params={{ appId }}
          className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          + New User
        </Link>
      </div>

      {users.length === 0 ? (
        <p className="text-sm text-primary/60">
          No users for this app yet.
        </p>
      ) : (
        <div className="overflow-x-auto rounded border border-border/60">
          <table className="min-w-full text-sm">
            <thead className="bg-muted/60">
              <tr className="[&>th]:px-3 [&>th]:py-2 text-left">
                <th>Email</th>
                <th>Name</th>
                <th>Role</th>
                <th>Created</th>
                <th className="w-32">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr
                  key={u._id}
                  className="border-t border-border/40 [&>td]:px-3 [&>td]:py-2"
                >
                  <td className="font-mono text-xs">{u.email}</td>
                  <td>{u.name}</td>
                  <td className="text-xs">
                    {u.roleId ? rolesMap.get(u.roleId) ?? "Unknown" : "—"}
                  </td>
                  <td className="text-xs text-primary/60">
                    {new Date(u.createdAt).toLocaleString()}
                  </td>
                  <td className="space-x-2 text-xs">
                    <Link
                      to="/_app/_auth/dashboard/apps/$appId/users/$userId/edit"
                      params={{ appId, userId: u._id }}
                      className="text-primary hover:underline"
                    >
                      Edit
                    </Link>
                    <button
                      onClick={() => onDelete(u._id)}
                      className="text-destructive hover:underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
