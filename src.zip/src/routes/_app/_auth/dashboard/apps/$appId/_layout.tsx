import { Outlet, createFileRoute, Link } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { Id } from "@cvx/_generated/dataModel";
import { useQuery } from "convex/react";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/_layout"
)({
  component: AppLayout,
});

function AppLayout() {
  const { appId } = Route.useParams();
  const typedId = appId as Id<"apps">;

  const app = useQuery(api.apps.getApp, { appId: typedId });

  if (!app) return <p>Loading...</p>;

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between">
        <h1 className="text-xl font-semibold">{app.name} - Overview</h1>

        <Link
          to="/_app/_auth/dashboard"
          className="px-3 py-2 bg-muted rounded"
        >
          ← Back
        </Link>
      </div>

      <Outlet />
    </div>
  );
}
