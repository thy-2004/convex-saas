// import { createFileRoute } from '@tanstack/react-router'

// export const Route = createFileRoute('/_app/_auth/dashboard/apps/$appId/roles/new')({
//   component: () => <div>Hello /_app/_auth/dashboard/apps/$appId/roles/new!</div>
// })
import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { Id } from "@cvx/_generated/dataModel";
import { useMutation } from "convex/react";
import { useState } from "react";
import { Button } from "@/ui/button";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/roles/new"
)({
  component: NewRolePage,
});

function NewRolePage() {
  const { appId } = Route.useParams();
  const typedAppId = appId as Id<"apps">;
  const router = useRouter();

  const createRole = useMutation(api.roles.createRole);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [permissionsText, setPermissionsText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const permissions = permissionsText
      .split(",")
      .map((p) => p.trim())
      .filter(Boolean);

    try {
      await createRole({
        appId: typedAppId,
        name,
        description: description || undefined,
        permissions,
      });

      router.navigate({
        to: "/_app/_auth/dashboard/apps/$appId/roles/",
        params: { appId },
      });
    } catch (err: any) {
      setError(err.message ?? "Failed to create role");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-lg font-semibold">New Role</h1>

      <form
        onSubmit={onSubmit}
        className="space-y-4 max-w-lg rounded border border-border/60 bg-card px-4 py-4"
      >
        <div className="space-y-1">
          <label className="block text-sm">Name</label>
          <input
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder="Admin, Member, Viewer..."
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm">Description</label>
          <textarea
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Optional description..."
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm">
            Permissions{" "}
            <span className="text-xs text-primary/60">
              (comma separated, ví dụ: users.read, users.write)
            </span>
          </label>
          <textarea
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm font-mono"
            rows={3}
            value={permissionsText}
            onChange={(e) => setPermissionsText(e.target.value)}
          />
        </div>

        {error && (
          <p className="text-sm text-destructive">{error}</p>
        )}

        <div className="flex items-center gap-3">
          <Button type="submit" disabled={loading}>
            {loading ? "Creating..." : "Create Role"}
          </Button>
          <Link
            to="/_app/_auth/dashboard/apps/$appId/roles/"
            params={{ appId }}
            className="text-sm text-primary/70 hover:underline"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}
