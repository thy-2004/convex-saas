import { createFileRoute, Link } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { Id } from "@cvx/_generated/dataModel";
import { useQuery, useMutation } from "convex/react";
import { Button } from "@/ui/button";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/roles/"
)({
  component: AppRolesPage,
});

function AppRolesPage() {
  const { appId } = Route.useParams();
  const typedAppId = appId as Id<"apps">;

  const roles = useQuery(api.roles.listRoles, { appId: typedAppId }) ?? [];
  const deleteRole = useMutation(api.roles.deleteRole);

  const onDelete = async (roleId: string) => {
    if (!confirm("Delete this role? Users will lose this role.")) return;
    await deleteRole({ roleId });
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Roles & Permissions</h1>

        <Link
          to="/_app/_auth/dashboard/apps/$appId/roles/new"
          params={{ appId }}
          className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          + New Role
        </Link>
      </div>

      {roles.length === 0 ? (
        <p className="text-sm text-primary/60">
          No roles yet. Create the first one.
        </p>
      ) : (
        <div className="overflow-x-auto rounded border border-border/60">
          <table className="min-w-full text-sm">
            <thead className="bg-muted/60">
              <tr className="[&>th]:px-3 [&>th]:py-2 text-left">
                <th>Name</th>
                <th>Description</th>
                <th>Permissions</th>
                <th className="w-32">Actions</th>
              </tr>
            </thead>
            <tbody>
              {roles.map((r) => (
                <tr
                  key={r._id}
                  className="border-t border-border/40 [&>td]:px-3 [&>td]:py-2"
                >
                  <td className="font-medium">{r.name}</td>
                  <td className="text-xs text-primary/70">
                    {r.description}
                  </td>
                  <td className="text-xs font-mono">
                    {r.permissions.join(", ")}
                  </td>
                  <td className="space-x-2">
                    <Link
                      to="/_app/_auth/dashboard/apps/$appId/roles/$roleId/edit"
                      params={{ appId, roleId: r._id }}
                      className="text-xs text-primary hover:underline"
                    >
                      Edit
                    </Link>
                    <button
                      onClick={() => onDelete(r._id)}
                      className="text-xs text-destructive hover:underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
