import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { api } from "@cvx/_generated/api";
import { Id, Doc } from "@cvx/_generated/dataModel";
import { useMutation, useQuery } from "convex/react";
import { useState } from "react";
import { Button } from "@/ui/button";

export const Route = createFileRoute(
  "/_app/_auth/dashboard/apps/$appId/users/new"
)({
  component: NewAppUserPage,
});

type Role = Doc<"roles">;

function NewAppUserPage() {
  const { appId } = Route.useParams();
  const typedAppId = appId as Id<"apps">;
  const router = useRouter();

  const createUser = useMutation(api.appUsers.createAppUser);
  const roles = (useQuery(api.roles.listRoles, {
    appId: typedAppId,
  }) ?? []) as Role[];

  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [roleId, setRoleId] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await createUser({
        appId: typedAppId,
        email,
        name,
        roleId: roleId || undefined,
      });

      router.navigate({
        to: "/_app/_auth/dashboard/apps/$appId/users/",
        params: { appId },
      });
    } catch (err: any) {
      setError(err.message ?? "Failed to create user");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-lg font-semibold">New User</h1>

      <form
        onSubmit={onSubmit}
        className="space-y-4 max-w-md rounded border border-border/60 bg-card px-4 py-4"
      >
        <div className="space-y-1">
          <label className="block text-sm">Email</label>
          <input
            type="email"
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="user@example.com"
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm">Name</label>
          <input
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full name"
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm">Role</label>
          <select
            className="w-full rounded border border-border/60 bg-background px-3 py-2 text-sm"
            value={roleId}
            onChange={(e) => setRoleId(e.target.value)}
          >
            <option value="">(No role)</option>
            {roles.map((r) => (
              <option key={r._id} value={r._id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>

        {error && (
          <p className="text-sm text-destructive">{error}</p>
        )}

        <div className="flex items-center gap-3">
          <Button type="submit" disabled={loading}>
            {loading ? "Creating..." : "Create User"}
          </Button>
          <Link
            to="/_app/_auth/dashboard/apps/$appId/users/"
            params={{ appId }}
            className="text-sm text-primary/70 hover:underline"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}
